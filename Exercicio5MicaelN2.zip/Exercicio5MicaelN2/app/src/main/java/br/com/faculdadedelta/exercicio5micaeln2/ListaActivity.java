package br.com.faculdadedelta.exercicio5micaeln2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import br.com.faculdadedelta.exercicio5micaeln2.adapter.AlunoAdapter;
import br.com.faculdadedelta.exercicio5micaeln2.dao.AlunoDAO;
import br.com.faculdadedelta.exercicio5micaeln2.modelo.Aluno;

public class ListaActivity extends AppCompatActivity {
    private ListView lvLista;
    private AlunoDAO dao = new AlunoDAO();

    private void carregarLista(){
        AlunoAdapter adapter = new AlunoAdapter(dao.listar(), getBaseContext());
        lvLista.setAdapter(adapter);
    }

    @Override
    protected void onResume() {
        super.onResume();
        carregarLista();
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lista);

        lvLista = findViewById(R.id.lvLista);

        lvLista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long id) {
                Aluno alunoSelecionado = (Aluno) adapterView.getItemAtPosition(i);

                Intent intent = new Intent(getBaseContext(), MainActivity.class);
                intent.putExtra("alunoSelecionado", alunoSelecionado);
                startActivity(intent);
            }
        });

        lvLista.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> adapterView, View view, int i, long l) {
                Aluno alunoSelecionado = (Aluno) adapterView.getItemAtPosition(i);
                dao.excluir(alunoSelecionado);
                carregarLista();

                return false;
            }
        });
    }
}
