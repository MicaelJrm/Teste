package br.com.faculdadedelta.exercicio5micaeln2.adapter;

import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.List;

import br.com.faculdadedelta.exercicio5micaeln2.R;
import br.com.faculdadedelta.exercicio5micaeln2.modelo.Aluno;

public class AlunoAdapter extends BaseAdapter {
    private List<Aluno> listaAluno;
    private Context context;

    public AlunoAdapter(List<Aluno> listaAluno, Context context) {
        this.listaAluno = listaAluno;
        this.context = context;
    }

    @Override
    public int getCount(){
        return listaAluno.size();
    }

    @Override
    public Object getItem(int i) {
        return listaAluno.get(i);
    }

    @Override
    public long getItemId(int i) {
        return i;
    }

    @Override
    public View getView(int i, View view, ViewGroup viewGroup) {
        Aluno aluno = (Aluno) getItem(i);

        View viewRetorno = view.inflate(context, R.layout.item_lista, null);

        TextView tvAluno = viewRetorno.findViewById(R.id.tvAluno);
        TextView tvDataNasc = viewRetorno.findViewById(R.id.tvDataNasc);
        TextView tvIdade = viewRetorno.findViewById(R.id.tvIdade);
        TextView tvGrau = viewRetorno.findViewById(R.id.tvGrau);

        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");


        tvAluno.setText("Nome do aluno: " + aluno.getAluno());
        tvIdade.setText("Idade: " + aluno.getIdade());
        tvDataNasc.setText("Data de Nascimento: " + sdf.format(aluno.getDataNasc()));
        tvGrau.setText("Grau de Instrução: " + aluno.getGrau());

        if (i%2 == 0){
            viewRetorno.setBackgroundColor(R.color.colorAccent);
        }

        return viewRetorno;
    }
}
