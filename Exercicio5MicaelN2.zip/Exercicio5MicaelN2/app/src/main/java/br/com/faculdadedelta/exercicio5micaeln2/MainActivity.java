package br.com.faculdadedelta.exercicio5micaeln2;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import br.com.faculdadedelta.exercicio5micaeln2.dao.AlunoDAO;
import br.com.faculdadedelta.exercicio5micaeln2.modelo.Aluno;

public class MainActivity extends AppCompatActivity {
    private EditText etAluno;
    private EditText etGrau;
    private EditText etIdade;
    private EditText etDataNasc;

    private Aluno aluno = new Aluno();
    private AlunoDAO dao = new AlunoDAO();
    private SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");

    private void limparCampos(){
        etAluno.setText("");
        etGrau.setText("");
        etIdade.setText("");
        etDataNasc.setText("");
        aluno = new Aluno();
    }

    private String validarCampos(){
        String texto = "";

        if (etAluno.getText().toString().isEmpty()) {
            texto += "\nO campo ALUNO obrigatório";
        }
        if (etIdade.getText().toString().isEmpty()) {
            texto += "\nO campo IDADE obrigatório";
        }
        if (etDataNasc.getText().toString().isEmpty()) {
            texto += "\nO campo DATA DE NASCIMENTO obrigatório";
        }
        if (etGrau.getText().toString().isEmpty()) {
            texto += "\nO campo GRAU obrigatório";
        }

        if (!etIdade.getText().toString().isEmpty()){
            if(Integer.parseInt(etIdade.getText().toString()) <= 0){
                texto += "Campo IDADE deve ser maior que 0";
            }
        }
        return texto;
    }

    private void popularFormulario(Aluno alunoSelecionado){
        etAluno.setText(alunoSelecionado.getAluno());
        etGrau.setText(String.valueOf(alunoSelecionado.getGrau()));
        etIdade.setText(String.valueOf(alunoSelecionado.getIdade()));
        etDataNasc.setText(sdf.format(alunoSelecionado.getDataNasc()));

        aluno.setId(alunoSelecionado.getId());
    }

    private void popularModelo(){
        aluno.setAluno(etAluno.getText().toString());
        aluno.setGrau(etIdade.getText().toString());
        aluno.setIdade(Integer.parseInt(etIdade.getText().toString()));

        try {
            aluno.setDataNasc(sdf.parse(etDataNasc.getText().toString()));
        } catch (ParseException e) {
            e.printStackTrace();
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etAluno = findViewById(R.id.etAluno);
        etGrau = findViewById(R.id.etGrau);
        etIdade = findViewById(R.id.etIdade);
        etDataNasc = findViewById(R.id.etDataNasc);

        Intent intent = getIntent();

        if (intent != null){
            Aluno alunoSelecionado = (Aluno) intent.getSerializableExtra("alunoSelecionado");

            if (alunoSelecionado != null){
                popularFormulario(alunoSelecionado);
            }
        }
    }

    public void salvar(View view){
        String validar = validarCampos();
        if (validar.isEmpty()) {
            popularModelo();
            if (aluno.getId() == null){
                dao.incluir(aluno);
                limparCampos();
                Toast.makeText(getBaseContext(), "Aluno incluido com sucesso!", Toast.LENGTH_LONG).show();
            }else{
                dao.alterar(aluno);
                limparCampos();
                Toast.makeText(getBaseContext(), "Aluno alterado com sucesso!", Toast.LENGTH_LONG).show();
            }
        }else{
            Toast.makeText(getBaseContext(), validar, Toast.LENGTH_LONG).show();
        }
    }

    public void listar(View view){
        Intent intent = new Intent(getBaseContext(), ListaActivity.class);
        startActivity(intent);
    }

    public void limpar(View view){limparCampos();}
}