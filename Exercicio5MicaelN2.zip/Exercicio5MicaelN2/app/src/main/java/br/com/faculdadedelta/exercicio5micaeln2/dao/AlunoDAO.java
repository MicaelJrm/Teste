package br.com.faculdadedelta.exercicio5micaeln2.dao;

import java.util.ArrayList;
import java.util.List;

import br.com.faculdadedelta.exercicio5micaeln2.modelo.Aluno;

public class AlunoDAO {
    private static List<Aluno> listaAluno = new ArrayList<>();
    private static Long idGenerator = 1L;

    public void incluir(Aluno aluno){
        aluno.setId(idGenerator++);
        listaAluno.add(aluno);
    }


    public void alterar(Aluno aluno){
        for (Aluno alunoAux: listaAluno) {
            long idAluno = aluno.getId();
            long idAlunoAux = alunoAux.getId();
            if (idAlunoAux == idAluno) {
                listaAluno.remove(alunoAux);
                listaAluno.add(aluno);
            }
        }
    }

    public void excluir(Aluno aluno) {listaAluno.remove(aluno);}

    public List<Aluno> listar() {return listaAluno;}

}
